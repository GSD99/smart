const PEDAGOGMarketContract = artifacts.require("PEDAGOGMarketContract");

module.exports = function (deployer) {
  deployer.deploy(PEDAGOGMarketContract);
};
