const PEDAGOGToken = artifacts.require("PEDAGOG");

module.exports = function (deployer) {
  deployer.deploy(PEDAGOGToken);
};
